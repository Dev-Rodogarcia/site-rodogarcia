# 🛠️ GUIA DE OTIMIZAÇÃO COM EXEMPLOS PRÁTICOS

Este documento complementa o `RELATORIO_OTIMIZACAO.md` com exemplos práticos de como resolver cada problema.

---

## 📌 PROBLEMA 1: Header e Footer Duplicados

### ❌ ANTES (Atual - Ruim)
```html
<!-- index.html -->
<header class="cabecalho">
    <div class="container cabecalho__container">
        <!-- ... 40 linhas ... -->
    </div>
</header>

<!-- servicos.html -->
<header class="cabecalho">
    <div class="container cabecalho__container">
        <!-- ... MESMAS 40 linhas ... -->
    </div>
</header>

<!-- sobre.html -->
<header class="cabecalho">
    <!-- ... REPETIDO NOVAMENTE ... -->
</header>
```

### ✅ DEPOIS (Otimizado - Bom)

**Opção 1: Usar JavaScript para incluir**
```html
<!-- Criar arquivo: components/header.html -->
<header class="cabecalho">
    <div class="container cabecalho__container">
        <!-- ... conteúdo do header ... -->
    </div>
</header>

<!-- Em cada página HTML -->
<div id="header-container"></div>
<script>
    fetch('components/header.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('header-container').innerHTML = data;
        });
</script>
```

**Opção 2: Usar PHP (se disponível)**
```php
<!-- header.php -->
<header class="cabecalho">
    <!-- ... conteúdo ... -->
</header>

<!-- Em cada página -->
<?php include 'header.php'; ?>
```

---

## 📌 PROBLEMA 2: Depoimentos Duplicados no HTML

### ❌ ANTES (300+ linhas duplicadas)
```html
<!-- servicos.html -->
<div class="carousel-depoimentos-track">
    <!-- 6 depoimentos originais -->
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>

    <!-- DUPLICAÇÃO: mesmos 6 depoimentos -->
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
</div>
```

### ✅ DEPOIS (Usar JavaScript)
```html
<!-- servicos.html - Apenas os originais -->
<div class="carousel-depoimentos-track" id="carouselDepoimentos">
    <!-- Apenas 6 depoimentos originais -->
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
    <div class="card-depoimento">...</div>
</div>

<script>
// Clonar automaticamente para criar loop infinito
const track = document.getElementById('carouselDepoimentos');
const cards = track.querySelectorAll('.card-depoimento');

// Clonar todos os cards
cards.forEach(card => {
    const clone = card.cloneNode(true);
    track.appendChild(clone);
});
</script>
```

**Redução:** De 600 linhas para 300 linhas + 10 linhas de JS = **50% de redução**

---

## 📌 PROBLEMA 3: Certificados Duplicados 4x

### ❌ ANTES (index.html - linhas 207-246)
```html
<div class="carousel-track">
    <!-- Grupo 1 -->
    <div class="carousel-slide">
        <img src="../public/certificados/certificado_iso_9001.png">
        <img src="../public/certificados/certificado_sassmaq.png">
        <!-- ... 6 imagens ... -->
    </div>
    
    <!-- Grupo 2 - DUPLICADO -->
    <div class="carousel-slide">
        <img src="../public/certificados/certificado_iso_9001.png">
        <!-- ... mesmas 6 imagens ... -->
    </div>
    
    <!-- Grupo 3 - DUPLICADO -->
    <!-- Grupo 4 - DUPLICADO -->
</div>
```

### ✅ DEPOIS
```html
<div class="carousel-track" id="carouselCertificados">
    <!-- Apenas 1 grupo original -->
    <div class="carousel-slide">
        <img src="../public/certificados/certificado_iso_9001.png" alt="ISO 9001">
        <img src="../public/certificados/certificado_sassmaq.png" alt="SASSMAQ">
        <img src="../public/certificados/licencas_ecovadis.png" alt="Ecovadis">
        <img src="../public/certificados/licenca_policia_federal.png" alt="PF">
        <img src="../public/certificados/licencas_exercito_brasileiro.png" alt="EB">
        <img src="../public/certificados/licencas_ibama.png" alt="IBAMA">
    </div>
</div>

<script>
// Clonar 3 vezes para criar 4 grupos
const track = document.getElementById('carouselCertificados');
const originalSlide = track.querySelector('.carousel-slide');

for (let i = 0; i < 3; i++) {
    const clone = originalSlide.cloneNode(true);
    track.appendChild(clone);
}
</script>
```

---

## 📌 PROBLEMA 4: Media Queries Repetidas

### ❌ ANTES (Espalhado em 8 arquivos)
```css
/* responsive.css */
@media (max-width: 768px) {
    .hero { padding: 3rem 0; }
    .titulo-secao { font-size: 1.5rem; }
}

/* responsive-servicos.css */
@media (max-width: 768px) {
    .hero-servicos { padding: 3rem 0; }
    .titulo-secao { font-size: 1.5rem !important; }
}

/* responsive-sobre.css */
@media (max-width: 768px) {
    .hero-sobre { padding: 4rem 0; }
    .titulo-secao { font-size: 2rem; }
}

/* footer.css */
@media (max-width: 768px) {
    .rodape { padding: 2.5rem 0; }
}

/* ... repetido em mais 4 arquivos ... */
```

### ✅ DEPOIS (Consolidado)
```css
/* responsive.css - ÚNICO ARQUIVO */
@media (max-width: 768px) {
    /* Hero - Base */
    .hero,
    .hero-servicos,
    .hero-sobre,
    .hero-cotacao {
        padding: 3rem 0 1.5rem;
    }
    
    /* Hero Sobre - Exceção */
    .hero-sobre {
        padding: 4rem 0 4rem;
    }
    
    /* Títulos - Geral */
    .titulo-secao {
        font-size: 1.5rem;
        margin-bottom: 0.75rem;
    }
    
    /* Rodapé */
    .rodape {
        padding: 2.5rem 0 1rem;
    }
    
    /* Grid - Torna tudo coluna única */
    .grid-dna,
    .grid-valores,
    .grid-rodape,
    .grid-historia,
    .grid-diferenciais-servicos {
        grid-template-columns: 1fr;
    }
}
```

**Redução:** De ~400 linhas espalhadas para ~100 linhas consolidadas

---

## 📌 PROBLEMA 5: Estilos de Botão Repetidos 3x

### ❌ ANTES (responsive.css)
```css
/* Linha 70-78 */
@media (max-width: 900px) {
    .botoes-acao .botao {
        width: 100% !important;
        flex: none !important;
        min-width: auto !important;
        max-width: 100% !important;
        font-size: 0.95rem !important;
        padding: 0.75rem 1.25rem !important;
        border-radius: 12px !important;
    }
}

/* Linha 428-443 */
@media (max-width: 768px) {
    .botoes-acao .botao {
        width: 100% !important;
        flex: none !important;
        min-width: auto !important;
        max-width: 100% !important;
        border-radius: 12px !important;
    }
}

/* Linha 512-521 */
@media (max-width: 480px) {
    .botoes-acao .botao {
        width: 100% !important;
        flex: none !important;
        min-width: auto !important;
        max-width: 100% !important;
        font-size: 0.9rem !important;
        padding: 0.7rem 1.2rem !important;
        border-radius: 12px !important;
    }
}
```

### ✅ DEPOIS (Consolidado)
```css
/* Base mobile - aplica a todos os breakpoints */
@media (max-width: 900px) {
    .botoes-acao .botao {
        width: 100%;
        flex: none;
        min-width: auto;
        max-width: 100%;
        border-radius: 12px;
        font-size: 0.95rem;
        padding: 0.75rem 1.25rem;
    }
}

/* Apenas ajustes específicos para telas menores */
@media (max-width: 480px) {
    .botoes-acao .botao {
        font-size: 0.9rem;
        padding: 0.7rem 1.2rem;
    }
}
```

**Redução:** De 30 linhas para 15 linhas + sem `!important`

---

## 📌 PROBLEMA 6: Icon-Wrapper Duplicado 4x

### ❌ ANTES (Em 4 arquivos diferentes)
```css
/* diferenciais.css */
.icon-wrapper {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    margin-bottom: 1.5rem;
}

.icon-wrapper.azul { background: var(--accent-azul); color: var(--cor-azul-hero); }
.icon-wrapper.roxo { background: var(--accent-roxo); color: var(--cor-azul-medio); }
.icon-wrapper.laranja { background: var(--accent-verde); color: var(--cor-apoio-escuro); }

/* diferenciais-servicos.css */
.icon-wrapper {
    /* ... MESMOS ESTILOS ... */
}

/* servicos-principais.css */
.icon-wrapper {
    /* ... MESMOS ESTILOS ... */
}

/* valores.css */
.icon-wrapper {
    /* ... MESMOS ESTILOS ... */
}
```

### ✅ DEPOIS (components/icons.css - arquivo único)
```css
/* components/icons.css */
.icon-wrapper {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    margin-bottom: 1.5rem;
}

/* Variações de cor */
.icon-wrapper.azul {
    background: var(--accent-azul);
    color: var(--cor-azul-hero);
}

.icon-wrapper.roxo {
    background: var(--accent-roxo);
    color: var(--cor-azul-medio);
}

.icon-wrapper.laranja {
    background: var(--accent-verde);
    color: var(--cor-apoio-escuro);
}

/* Variações de tamanho */
.icon-wrapper--small {
    width: 50px;
    height: 50px;
    font-size: 1.75rem;
}

.icon-wrapper--large {
    width: 80px;
    height: 80px;
    font-size: 2.5rem;
}
```

**Importar uma única vez no main.css:**
```css
/* main.css */
@import 'components/icons.css';
```

---

## 📌 PROBLEMA 7: Cards Base Duplicados

### ❌ ANTES (Em 4 arquivos)
```css
/* diferenciais.css */
.card-diferencial {
    background: white;
    padding: 2.5rem;
    border-radius: var(--radius-md);
    border: 1px solid var(--cor-borda);
    transition: transform 0.3s, box-shadow 0.3s;
}

.card-diferencial:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
}

/* valores.css */
.card-valor {
    /* ... MESMOS ESTILOS ... */
}

/* servicos-principais.css */
.card-servico-principal {
    /* ... MESMOS ESTILOS ... */
}
```

### ✅ DEPOIS (components/cards.css)
```css
/* components/cards.css */

/* Classe base para todos os cards */
.card {
    background: white;
    padding: 2.5rem;
    border-radius: var(--radius-md);
    border: 1px solid var(--cor-borda);
    transition: transform 0.3s, box-shadow 0.3s;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    border-color: transparent;
}

/* Variações específicas */
.card--diferencial {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    height: 100%;
}

.card--servico {
    text-align: center;
}

.card--valor {
    /* estilos específicos de valores */
}

/* Tamanhos */
.card--compact {
    padding: 1.5rem;
}

.card--large {
    padding: 3rem;
}
```

**Uso no HTML:**
```html
<!-- Antes -->
<div class="card-diferencial">...</div>

<!-- Depois -->
<div class="card card--diferencial">...</div>
```

---

## 📌 PROBLEMA 8: Ícones Decorativos Escondidos

### ❌ ANTES (responsive.css linhas 102-118)
```css
@media (max-width: 900px) {
    .icon-pin {
        display: none;
    }
    
    .icon-box {
        display: none;
    }
    
    .icon-plane {
        display: none;
    }
    
    .hero-decorations {
        display: none;
    }
    
    .hero-glow {
        display: none;
    }
    
    .hero-pattern-dots {
        display: none;
    }
}
```

### ✅ DEPOIS (Consolidado)
```css
@media (max-width: 900px) {
    /* Esconde todos os elementos decorativos do hero */
    .icon-pin,
    .icon-box,
    .icon-plane,
    .hero-decorations,
    .hero-glow,
    .hero-pattern-dots {
        display: none;
    }
}
```

**Redução:** De 17 linhas para 8 linhas

---

## 📌 PROBLEMA 9: Animações Duplicadas

### ❌ ANTES (Definida 2x)
```css
/* responsive.css */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* mapa.css */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
```

### ✅ DEPOIS (base/animations.css - novo arquivo)
```css
/* base/animations.css */

/* Animações globais usadas em todo o site */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(50px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

@keyframes bounce {
    0%, 20%, 50%, 80%, 100% {
        transform: translate(-50%, -100%);
    }
    40% {
        transform: translate(-50%, -130%);
    }
    60% {
        transform: translate(-50%, -115%);
    }
}

/* Outras animações globais... */
```

**Importar no main.css:**
```css
/* main.css */
@import 'base/animations.css';
```

---

## 📌 PROBLEMA 10: Excesso de !important

### ❌ ANTES (responsive.css)
```css
.hero {
    padding-top: 3rem !important;
    padding-bottom: 1.5rem !important;
    padding-left: 1rem !important;
    padding-right: 1rem !important;
    margin-top: 0 !important;
}

.titulo-hero {
    font-size: 1.75rem !important;
    line-height: 1.3 !important;
    margin-bottom: 1rem !important;
    margin-top: 0 !important;
    order: 1 !important;
    font-weight: 800 !important;
}
```

### ✅ DEPOIS (Aumentar especificidade sem !important)
```css
/* Usar especificidade correta */
@media (max-width: 900px) {
    .hero.hero {
        padding: 3rem 1rem 1.5rem;
        margin-top: 0;
    }
    
    .hero .titulo-hero {
        font-size: 1.75rem;
        line-height: 1.3;
        margin: 0 0 1rem 0;
        order: 1;
        font-weight: 800;
    }
}
```

**OU usar shorthand:**
```css
.hero {
    /* Ao invés de 4 propriedades separadas */
    padding: 3rem 1rem 1.5rem;
    
    /* Ao invés de margin-top e margin-bottom separados */
    margin: 0 0 1rem 0;
}
```

---

## 📌 PROBLEMA 11: Classes CSS Não Utilizadas

### ❌ ANTES (base.css linhas 72-88)
```css
/* Utilitários de Cor - NÃO USADOS */
.color-blue {
    color: var(--cor-azul-hero);
}

.color-green {
    color: #27ae60;
}

.color-orange {
    color: var(--cor-apoio-escuro);
}

.color-purple {
    color: var(--cor-azul-hero);
}
```

### ✅ DEPOIS
```css
/* REMOVER COMPLETAMENTE */
/* Se não são usadas, não devem existir */
```

**OU se quiser manter para uso futuro:**
```css
/* utils/colors.css - arquivo separado */
/* Utilitários de cor (carregar apenas se necessário) */
.u-color-blue { color: var(--cor-azul-hero); }
.u-color-green { color: #27ae60; }
.u-color-orange { color: var(--cor-apoio-escuro); }
```

---

## 📌 PROBLEMA 12: Grid Responsivo Duplicado

### ❌ ANTES (Em vários arquivos)
```css
/* dna.css */
@media (max-width: 768px) {
    .grid-dna {
        grid-template-columns: 1fr;
    }
}

/* valores.css */
@media (max-width: 768px) {
    .grid-valores {
        grid-template-columns: 1fr;
    }
}

/* footer.css */
@media (max-width: 768px) {
    .grid-rodape {
        grid-template-columns: 1fr;
    }
}
```

### ✅ DEPOIS (Classe utilitária)
```css
/* base/utilities.css */
@media (max-width: 768px) {
    /* Classe genérica para grids que viram coluna única */
    .grid-responsive {
        grid-template-columns: 1fr !important;
    }
}
```

**Uso no HTML:**
```html
<!-- Adicionar classe utilitária -->
<div class="grid-dna grid-responsive">...</div>
<div class="grid-valores grid-responsive">...</div>
<div class="grid-rodape grid-responsive">...</div>
```

---

## 📊 ESTRUTURA FINAL RECOMENDADA

```
css/
├── base/
│   ├── variables.css       (cores, tamanhos)
│   ├── reset.css          (reset básico)
│   ├── typography.css     (fontes e textos)
│   ├── animations.css     (todas as @keyframes)
│   └── utilities.css      (classes utilitárias)
│
├── components/
│   ├── buttons.css        (todos os botões)
│   ├── cards.css          (cards base)
│   ├── icons.css          (icon-wrapper)
│   └── forms.css          (inputs, selects)
│
├── layout/
│   ├── header.css         (header desktop)
│   ├── footer.css         (footer)
│   └── grid.css           (sistemas de grid)
│
├── pages/
│   ├── home.css           (específico da home)
│   ├── servicos.css       (específico de serviços)
│   └── sobre.css          (específico de sobre)
│
├── responsive.css         (ÚNICO arquivo com media queries)
└── main.css              (importa tudo na ordem correta)
```

---

## 🎯 CHECKLIST DE IMPLEMENTAÇÃO

### Fase 1: Estrutura (1-2 dias)
- [ ] Criar estrutura de pastas otimizada
- [ ] Criar arquivo `animations.css` com todas as animações
- [ ] Criar arquivo `cards.css` com estilos base de cards
- [ ] Criar arquivo `icons.css` com icon-wrapper

### Fase 2: Consolidação CSS (2-3 dias)
- [ ] Mover todas as media queries para `responsive.css`
- [ ] Remover duplicações de estilos
- [ ] Eliminar `!important` desnecessários
- [ ] Criar classes utilitárias

### Fase 3: HTML (1-2 dias)
- [ ] Componentizar header e footer
- [ ] Usar JavaScript para clonar carrosséis
- [ ] Atualizar classes nos HTMLs

### Fase 4: Limpeza (1 dia)
- [ ] Remover código órfão
- [ ] Remover comentários vazios
- [ ] Testar todas as páginas

### Fase 5: Testes (1 dia)
- [ ] Testar em diferentes navegadores
- [ ] Testar responsividade
- [ ] Validar performance

---

## 📈 MÉTRICAS DE SUCESSO

### Antes da Otimização:
- **Total de linhas CSS:** ~3.500 linhas
- **Total de linhas HTML:** ~2.000 linhas
- **Arquivos CSS:** 37 arquivos
- **Duplicações:** ~1.740 linhas

### Depois da Otimização (Esperado):
- **Total de linhas CSS:** ~2.000 linhas (-43%)
- **Total de linhas HTML:** ~1.200 linhas (-40%)
- **Arquivos CSS:** 20 arquivos (-46%)
- **Duplicações:** ~100 linhas (-95%)

---

**FIM DO GUIA**

