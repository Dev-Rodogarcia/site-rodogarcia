# 🔍 ÍNDICE RÁPIDO - Onde Está Cada Problema

Este documento serve como referência rápida para localizar problemas específicos no código.

---

## 📁 PROBLEMAS POR ARQUIVO

### 🔴 index.html (376 linhas)
| Linha | Problema | Gravidade |
|-------|----------|-----------|
| 29-73 | Header duplicado | 🔴 Alta |
| 207-246 | Certificados duplicados 4x (160 linhas) | 🔴 Alta |
| 326-368 | Footer duplicado | 🔴 Alta |

**Total de Duplicação:** ~240 linhas (63%)

---

### 🔴 servicos.html (623 linhas)
| Linha | Problema | Gravidade |
|-------|----------|-----------|
| 30-73 | Header duplicado | 🔴 Alta |
| 245-407 | Depoimentos originais | - |
| 409-551 | Depoimentos DUPLICADOS (300 linhas) | 🔴 Alta |
| 576-619 | Footer duplicado | 🔴 Alta |

**Total de Duplicação:** ~380 linhas (60%)

---

### 🔴 sobre.html
| Linha | Problema | Gravidade |
|-------|----------|-----------|
| 30-73 | Header duplicado | 🔴 Alta |
| ~280-320 | Footer duplicado | 🔴 Alta |

**Total de Duplicação:** ~80 linhas

---

### 🔴 cotacao.html
| Linha | Problema | Gravidade |
|-------|----------|-----------|
| 30-73 | Header duplicado | 🔴 Alta |
| ~280-320 | Footer duplicado | 🔴 Alta |

**Total de Duplicação:** ~80 linhas

---

### 🔴 trabalhe-conosco.html
| Linha | Problema | Gravidade |
|-------|----------|-----------|
| ~30-73 | Header duplicado | 🔴 Alta |

**Total de Duplicação:** ~40 linhas

---

## 📁 PROBLEMAS CSS POR ARQUIVO

### 🔴 responsive.css (542 linhas) - ARQUIVO MAIS PROBLEMÁTICO

#### Media Query: @media (max-width: 900px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 7-15 | `.hero` com !important | Remover !important |
| 25-31 | `.hero__texto` duplicado 3x | Consolidar |
| 33-40 | `.titulo-hero` duplicado 4x | Consolidar |
| 42-49 | `.subtitulo-hero` duplicado 3x | Consolidar |
| 70-78 | `.botoes-acao .botao` duplicado 3x | Consolidar |
| 89-99 | `.img-hero-destaque` duplicado 3x | Consolidar |
| 102-118 | Ícones escondidos separadamente | Agrupar seletores |
| 130-275 | Menu mobile com excesso de !important | Reorganizar especificidade |

#### Media Query: @media (max-width: 768px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 378-464 | Estilos repetidos de outros arquivos | Consolidar tudo aqui |
| 393-463 | Hero mobile repetido | Já existe em 900px |
| 428-443 | Botões repetidos | Já existe em 900px |

#### Media Query: @media (max-width: 480px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 467-540 | Estilos repetidos novamente | Consolidar |
| 481-488 | `.titulo-hero` 4ª vez | Consolidar |
| 512-521 | `.botoes-acao` 3ª vez | Consolidar |
| 531-539 | `.img-hero-destaque` 3ª vez | Consolidar |

**Problemas Principais:**
- 80+ ocorrências de `!important`
- Estilos repetidos 3-4 vezes
- Mesmos breakpoints em múltiplos lugares

---

### 🟡 responsive-servicos.css (391 linhas)

#### Media Query: @media (max-width: 968px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 6-55 | Grid e carousel | Mover para responsive.css |

#### Media Query: @media (max-width: 768px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 58-223 | Muitos estilos específicos | Consolidar com responsive.css |
| 138-145 | `.titulo-secao` com !important | Já definido em base |
| 180-187 | `@keyframes scrollDepoimentos` 2ª vez | Mover para animations.css |

#### Media Query: @media (max-width: 480px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 226-390 | Estilos repetidos | Consolidar |
| 348-355 | `@keyframes scrollDepoimentos` 3ª vez | Remover |

---

### 🟡 responsive-sobre.css (282 linhas)

#### Media Query: @media (max-width: 968px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 6-62 | Estilos específicos de sobre | OK, mas consolidar |

#### Media Query: @media (max-width: 768px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 65-181 | Muitos estilos gerais | Mover para responsive.css |
| 133-139 | `.titulo-secao` redefinido | Já existe em base |

#### Media Query: @media (max-width: 480px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 184-281 | Estilos repetidos | Consolidar |

---

### 🟡 responsive-cotacao.css (69 linhas)

#### Media Query: @media (max-width: 768px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 18-44 | Estilos de formulário | Mover para responsive.css |

**Observação:** Arquivo pequeno, mas poderia ser integrado ao responsive.css principal.

---

### 🟡 footer.css (195 linhas)

#### Estilos Base
| Linha | Problema | Solução |
|-------|----------|---------|
| 1-55 | Estilos base OK | Manter |

#### Media Query: @media (max-width: 968px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 57-85 | Grid responsivo | Mover para responsive.css |

#### Media Query: @media (max-width: 768px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 88-147 | Estilos mobile | Mover para responsive.css |

#### Media Query: @media (max-width: 480px)
| Linha | Problema | Solução |
|-------|----------|---------|
| 150-195 | Estilos mobile pequeno | Mover para responsive.css |

---

### 🟡 header.css (67 linhas)

**Status:** ✅ Arquivo OK, sem grandes problemas

---

### 🟡 hero.css (207 linhas)

| Linha | Problema | Solução |
|-------|----------|---------|
| 1-207 | Estilos base OK | Manter |

**Observação:** Arquivo bem estruturado, mas é sobrescrito com !important no responsive.css

---

### 🟡 diferenciais.css (64 linhas)

| Linha | Problema | Solução |
|-------|----------|---------|
| 28-53 | `.icon-wrapper` duplicado | Mover para components/icons.css |
| 10-26 | `.card-diferencial` base | Mover para components/cards.css |

---

### 🟡 diferenciais-servicos.css

| Linha | Problema | Solução |
|-------|----------|---------|
| - | `.icon-wrapper` duplicado | Usar de components/icons.css |
| - | `.card-diferencial-servico` | Usar de components/cards.css |

---

### 🟡 servicos-principais.css

| Linha | Problema | Solução |
|-------|----------|---------|
| - | `.icon-wrapper` duplicado | Usar de components/icons.css |
| - | `.card-servico-principal` | Usar de components/cards.css |

---

### 🟡 valores.css

| Linha | Problema | Solução |
|-------|----------|---------|
| - | `.icon-wrapper` duplicado | Usar de components/icons.css |
| - | `.card-valor` | Usar de components/cards.css |

---

### 🟡 dna.css (208 linhas)

| Linha | Problema | Solução |
|-------|----------|---------|
| 75-78 | `.card-glass` órfão | Remover (não usado) |
| 105-163 | @media (max-width: 768px) | Mover para responsive.css |
| 166-208 | @media (max-width: 480px) | Mover para responsive.css |

---

### 🟡 filiais.css (275 linhas)

| Linha | Problema | Solução |
|-------|----------|---------|
| 1-135 | Estilos base OK | Manter |
| 137-198 | @media (max-width: 968px, 768px) | Mover para responsive.css |
| 200-270 | @media (max-width: 480px) | Mover para responsive.css |

---

### 🟡 rastreio.css (178 linhas)

| Linha | Problema | Solução |
|-------|----------|---------|
| 1-67 | Estilos base OK | Manter |
| 69-133 | @media (max-width: 968px, 768px) | Mover para responsive.css |
| 136-178 | @media (max-width: 480px) | Mover para responsive.css |

---

### 🟡 mapa.css (152 linhas)

| Linha | Problema | Solução |
|-------|----------|---------|
| 129-139 | `@keyframes fadeIn` duplicada | Mover para animations.css |
| 142-152 | `@keyframes shake` | Mover para animations.css |

---

### 🟢 base.css (89 linhas)

| Linha | Problema | Solução |
|-------|----------|---------|
| 72-88 | Classes utilitárias não usadas | Remover ou mover para utilities.css |

**Observação:** Arquivo bem estruturado.

---

### 🟢 variables.css (45 linhas)

**Status:** ✅ Arquivo perfeito, sem problemas

---

### 🟢 buttons.css (94 linhas)

**Status:** ✅ Arquivo bem estruturado, sem grandes problemas

---

## 🎯 MAPA DE CALOR - ARQUIVOS POR GRAVIDADE

```
🔴 CRÍTICO (Ação Imediata)
├─ responsive.css (542 linhas, 80+ !important)
├─ servicos.html (300 linhas duplicadas)
├─ index.html (240 linhas duplicadas)
└─ Todos os HTMLs (header/footer)

🟡 IMPORTANTE (Ação em Breve)
├─ responsive-servicos.css (391 linhas)
├─ responsive-sobre.css (282 linhas)
├─ footer.css (195 linhas com media queries)
├─ filiais.css (275 linhas com media queries)
├─ rastreio.css (178 linhas com media queries)
├─ dna.css (208 linhas com media queries)
└─ 4 arquivos com icon-wrapper duplicado

🟢 BAIXA PRIORIDADE (Melhorias)
├─ base.css (classes não usadas)
├─ mapa.css (animações duplicadas)
└─ Comentários vazios em vários arquivos
```

---

## 🔧 QUICK REFERENCE - ONDE MUDAR O QUÊ

### Para mudar o HEADER:
```
❌ ANTES: Mudar em 5 lugares
   • index.html (linhas 29-73)
   • servicos.html (linhas 30-73)
   • sobre.html (linhas 30-73)
   • cotacao.html (linhas 30-73)
   • trabalhe-conosco.html (linhas ~30-73)

✅ DEPOIS: Mudar em 1 lugar
   • components/header.html
```

### Para mudar o FOOTER:
```
❌ ANTES: Mudar em 4 lugares
   • index.html (linhas 326-368)
   • servicos.html (linhas 576-619)
   • sobre.html (linhas ~280-320)
   • cotacao.html (linhas ~280-320)

✅ DEPOIS: Mudar em 1 lugar
   • components/footer.html
```

### Para mudar estilos MOBILE:
```
❌ ANTES: Procurar em 8+ arquivos
   • responsive.css
   • responsive-servicos.css
   • responsive-sobre.css
   • responsive-cotacao.css
   • footer.css
   • dna.css
   • filiais.css
   • rastreio.css

✅ DEPOIS: Mudar em 1 lugar
   • base/responsive.css (consolidado)
```

### Para mudar ICON-WRAPPER:
```
❌ ANTES: Mudar em 4 lugares
   • diferenciais.css
   • diferenciais-servicos.css
   • servicos-principais.css
   • valores.css

✅ DEPOIS: Mudar em 1 lugar
   • components/icons.css
```

### Para mudar CARDS BASE:
```
❌ ANTES: Mudar em 4 lugares
   • diferenciais.css (.card-diferencial)
   • diferenciais-servicos.css (.card-diferencial-servico)
   • servicos-principais.css (.card-servico-principal)
   • valores.css (.card-valor)

✅ DEPOIS: Mudar em 1 lugar
   • components/cards.css (.card)
```

---

## 📋 CHECKLIST DE BUSCA RÁPIDA

### Encontrar Duplicações HTML
```bash
# Header
grep -n "class=\"cabecalho\"" src/*.html

# Footer
grep -n "class=\"rodape\"" src/*.html

# Depoimentos
grep -n "card-depoimento" src/servicos.html | wc -l

# Certificados
grep -n "carousel-slide" src/index.html | wc -l
```

### Encontrar Duplicações CSS
```bash
# Icon-wrapper
grep -rn "\.icon-wrapper {" src/css/

# Media queries 768px
grep -rn "@media (max-width: 768px)" src/css/ | wc -l

# !important
grep -rn "!important" src/css/ | wc -l

# Animações
grep -rn "@keyframes" src/css/
```

### Encontrar Classes Não Usadas
```bash
# Buscar classe no CSS
grep -rn "\.color-blue" src/css/

# Buscar uso no HTML
grep -rn "color-blue" src/*.html

# Se não aparecer no HTML, está órfã
```

---

## 🎯 PRIORIZAÇÃO POR IMPACTO

### Alto Impacto (Fazer Primeiro)
1. **Header/Footer** → Economiza 360 linhas, facilita manutenção
2. **Depoimentos** → Economiza 300 linhas HTML
3. **Media Queries** → Economiza 700 linhas CSS, organiza código
4. **Certificados** → Economiza 160 linhas HTML

### Médio Impacto (Fazer em Seguida)
5. **Icon-wrapper** → Economiza 100 linhas, facilita manutenção
6. **Cards Base** → Economiza 80 linhas, padroniza componentes
7. **Animações** → Economiza 65 linhas, organiza código

### Baixo Impacto (Fazer Depois)
8. **Código Órfão** → Economiza 50 linhas, limpa código
9. **Comentários** → Economiza 20 linhas, limpa código
10. **!important** → Não economiza linhas, mas melhora qualidade

---

## 📞 CONTATOS RÁPIDOS

### Arquivos de Documentação
- 📄 **RELATORIO_OTIMIZACAO.md** - Análise completa e detalhada
- 🛠️ **GUIA_OTIMIZACAO_EXEMPLOS.md** - Exemplos práticos de código
- 📊 **RESUMO_VISUAL.md** - Gráficos e estatísticas
- 🔍 **INDICE_RAPIDO.md** - Este arquivo (referência rápida)

### Estrutura Recomendada
```
src/
├── components/
│   ├── header.html (NOVO)
│   └── footer.html (NOVO)
├── css/
│   ├── base/
│   │   ├── animations.css (NOVO - todas as @keyframes)
│   │   ├── utilities.css (NOVO - classes utilitárias)
│   │   └── responsive.css (CONSOLIDADO - todas media queries)
│   └── components/
│       ├── cards.css (NOVO - todos os cards)
│       └── icons.css (NOVO - icon-wrapper)
```

---

**Última Atualização:** 23/12/2025
**Status:** ✅ Completo e Pronto para Uso

